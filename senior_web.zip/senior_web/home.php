<?php
session_start();

// Check if the user is logged in
if (isset($_SESSION['username'])) {
    // User is logged in, show a "Welcome" message and logout option
    $logged_in = true;
} else {
    // User is not logged in, show sign-in / sign-up links
    $logged_in = false;
}

// Check if the user clicked on 'Ministries'
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['from']) && $_POST['from'] === 'ministries') {
    $_SESSION['redirect_after_login'] = 'ministries.html';  // Save the redirect URL in session
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Lebanon Government Services</title>
</head>
<body>

  <!-- Background Image -->
  <div class="bg-image">
    <img src="WhatsApp Image 2025-04-19 at 20.43.20_27e6ff55.jpg" alt="Rochi Lebanon">
  </div>

  <!-- Page Content -->
  <div class="overlay">
    <header>
      <div class="logo">
        <img src="lebanese flag.jpg" alt="Logo" />
      </div>
      
      <nav>
        <!-- Ministries link, shown only if the user is logged in -->
        <?php if ($logged_in): ?>
          <a href="ministries.html">Ministries</a>
          <a href="logout.php">Logout</a>
        <?php else: ?>
         
          <form method="POST" action="access.php" style="display: inline;">
  <input type="hidden" name="from" value="ministries">
  <button type="submit" class="nav-link-button">Ministries</button>
</form>

          <a href="access.php">Sign In</a>
          <a href="access.php?signup=1">Sign Up</a>
        <?php endif; ?>
        
        <a href="#">Calendar</a>
        <a href="#" id="aboutBtn">About Us</a>
      </nav>
      
    </header>

    <main>
      <section class="news">
        <h1>Live News in Lebanon</h1>
        <div id="news-feed">
          <p>Loading latest news...</p>
        </div>
      </section>
    </main>

    <footer>
      <div class="footer-contacts">
        <span>📱 WhatsApp: +961 76 000 000</span>
        <span>🚑 Red Cross: 140</span>
        <span>🚒 Firefighter: 175</span>
        <span>🚓 Police: 112</span>
      </div>
    </footer>
    
  <div id="aboutModal" class="modal">
    <div class="modal-content">
      <span class="close">&times;</span>
      <p>
        This platform helps Lebanese citizens save time and money by simplifying the process of obtaining official documents and accessing government services online.
      </p>
    </div>
  </div>

  <script>
    const modal = document.getElementById("aboutModal");
    const btn = document.getElementById("aboutBtn");
    const span = document.getElementsByClassName("close")[0];

    btn.onclick = () => modal.style.display = "block";
    span.onclick = () => modal.style.display = "none";
    window.onclick = (e) => { if (e.target == modal) modal.style.display = "none"; };

    fetch("news.php")
      .then(res => res.json())
      .then(data => {
        const newsFeed = document.getElementById('news-feed');
        newsFeed.innerHTML = '';

        if (data.status !== "ok") {
          newsFeed.innerHTML = `<p>⚠ Error from API: ${data.message}</p>`;
          return;
        }

        if (data.articles.length === 0) {
          newsFeed.innerHTML = "<p>No recent news found.</p>";
        }

        data.articles.forEach(article => {
          const p = document.createElement('p');
          p.innerHTML = ` 📰 <a href="${article.url}" target="_blank" style="color: #ffd700;">${article.title}</a>`;
          newsFeed.appendChild(p);
        });
      })
      .catch(error => {
        document.getElementById('news-feed').innerHTML = "<p>⚠ Failed to load news.</p>";
        console.error("Fetch Error:", error);
      });
  </script>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      color: white;
    }

    /* Background image full screen */
    .bg-image {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: -1;
      overflow: hidden;
    }

    .bg-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .overlay {
      background-color: rgba(0, 0, 0, 0.6);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px 40px;
      background: rgba(0, 0, 0, 0.7);
    }

    .logo img {
      height: 50px;
      width: auto;
    }

    nav a {
      margin-left: 20px;
      text-decoration: none;
      color: #fff;
      font-weight: bold;
    }

    nav a:hover {
      text-decoration: underline;
    }
    .nav-link-button {
  background: none;
  border: none;
  color: #fff;
  font-weight: bold;
  cursor: pointer;
  text-decoration: none;
  margin-left: 20px;
  font-family: inherit;
  font-size: inherit;
}

.nav-link-button:hover {
  text-decoration: underline;
}


    main {
      display: flex;
      justify-content: center;
      text-align: center;
      padding: 80px 20px;
      flex-grow: 1;
    }

    .news {
      background: rgba(255, 255, 255, 0.1);
      padding: 40px;
      border-radius: 15px;
      max-width: 600px;
    }

    .news h1 {
      margin-bottom: 20px;
      font-size: 28px;
      color: #ffd700;
    }

    .footer-contacts {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 80px;
      flex-wrap: wrap;
    }

    .footer-contacts span {
      white-space: nowrap;
      font-size: 16px;
      color: white;
    }

    /* Modal styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 2;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.6);
    }

    .modal-content {
      background-color: #fff;
      color: #333;
      margin: 15% auto;
      padding: 20px;
      border-radius: 10px;
      width: 50%;
      text-align: center;
    }

    .close {
      color: #333;
      float: right;
      font-size: 24px;
      font-weight: bold;
      cursor: pointer;
    }

    #news-feed p {
      margin-bottom: 10px;
      font-size: 16px;
      line-height: 1.4;
      color: white;
    }
  </style>

  <div id="accessModal" class="modal">
    <div class="modal-content">
      <span class="close" onclick="document.getElementById('accessModal').style.display='none'">&times;</span>
      <h2>Login or Register to Access Ministries</h2>
      <p>
        <button onclick="window.location.href='login.php'">Sign In</button>
        <button onclick="window.location.href='register.php'">Sign Up</button>
      </p>
    </div>
  </div>

</body>
</html>

<?php
session_start();
if ($_SESSION['role'] != 'super_admin') {
    header("Location: login.php");
    exit();
}

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ministry_name = $_POST['ministry_name'];
    $ministry_desc = $_POST['ministry_desc'];
    
    // Insert new ministry
    $stmt = $conn->prepare("INSERT INTO ministries (name, description) VALUES (?, ?)");
    $stmt->bind_param("ss", $ministry_name, $ministry_desc);
    
    if ($stmt->execute()) {
        echo "وزارة جديدة تم إضافتها.";
    } else {
        echo "حدث خطأ أثناء إضافة الوزارة.";
    }
}
?>

<form method="POST" action="add_ministry.php">
  <label for="ministry_name">اسم الوزارة:</label>
  <input type="text" name="ministry_name" required><br>
  
  <label for="ministry_desc">وصف الوزارة:</label>
  <textarea name="ministry_desc" required></textarea><br>
  
  <button type="submit">إضافة الوزارة</button>
</form>

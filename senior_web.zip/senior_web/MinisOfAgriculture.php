<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>وزارة الزراعة</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background-color: #f4fbf5;
      margin: 0;
      padding: 0;
      direction: rtl;
      color: #2e4034;

      font-family: 'Inter', sans-serif;
      margin: 0;
      padding: 0;
      direction: rtl;
      color: #2e4034;
      background-image: url('AdobeStock_303214121_-Dusan-Kostic.jpeg');
      background-size: cover;
      background-attachment: fixed;
      background-repeat: no-repeat;
      background-position: center;
    
    }

    .header {
      background-color: #61b659;
      padding: 0;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .header img {
      width: 100%;
      height: 300px;
      object-fit: cover;
      border-bottom: 5px solid #68b684;
    }

    .header h1 {
      margin: 0;
      padding: 20px;
      font-size: 36px;
      text-align: center;
      color: #103c2d;
    }

    .container {
      max-width: 900px;
      margin: 40px auto;
      padding: 0 20px;
    }

    .section {
      background-color: #ffffff;
      border-radius: 15px;
      padding: 25px;
      margin-bottom: 30px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.05);
    }

    .section h2 {
      margin-top: 0;
      font-size: 24px;
      color: #146c43;
    }

    .section p {
      font-size: 17px;
      line-height: 1.8;
      color: #2e4034;
    }

    .services ul {
      padding-right: 20px;
      line-height: 2;
    }

    .back-link {
      display: block;
      margin: 30px auto;
      text-align: center;
      text-decoration: none;
      font-weight: bold;
      color: #f7f9ff;
      transition: color 0.3s;
    }

    .back-link:hover {
      color: #e70b96;
    }
    .preview-box img {
    display: block;
  }

    form label {
      display: block;
      margin-bottom: 8px;
      font-weight: bold;
      color: #103c2d;
    }

    form input, form textarea, form select {
      width: 100%;
      padding: 12px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 10px;
      font-family: inherit;
    }

    form button {
      background-color: #68b684;
      color: white;
      border: none;
      padding: 12px 20px;
      border-radius: 10px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    form button:hover {
      background-color: #4e9d6c;
    }
    .preview-box img {
  display: block;
  max-width: 150px;
  margin-top: 10px;
  border-radius: 12px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
  transition: transform 0.3s ease, opacity 0.4s ease;
  opacity: 0;
  animation: fadeIn 0.5s forwards;
}

.preview-box img:hover {
  transform: scale(1.05);
}

@keyframes fadeIn {
  to {
    opacity: 1;
  }
}

.service-form button {
  background-color: #2d8cf0;
  color: white;
  padding: 10px 18px;
  border: none;
  border-radius: 8px;
  margin-top: 15px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.service-form button:hover {
  background-color: #1b6edc;
}
.popup-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999;
}

.popup-content {
  background-color: #fff;
  padding: 30px 40px;
  border-radius: 12px;
  box-shadow: 0 0 20px rgba(0,0,0,0.2);
  text-align: center;
  animation: popupFade 0.5s ease-in-out;
}

@keyframes popupFade {
  from { transform: scale(0.9); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}


  </style>
</head>
<body>

  <div class="header">
    <h1>وزارة الزراعة اللبنانية</h1>
  </div>

  <div class="container">

    <div class="section">
      <h2>المهام الرئيسية</h2>
      <p>
        تُعنى وزارة الزراعة بدعم القطاع الزراعي في لبنان من خلال تنظيم الإنتاج الزراعي، منح التراخيص، مراقبة الجودة، واستيراد وتصدير المنتجات الزراعية.
        كما تعمل على تأمين الإرشاد الزراعي للمزارعين، وتطوير مشاريع تنموية في المناطق الريفية.
      </p>
    </div>

    <div class="section services">
      <h2>الخدمات المقدّمة</h2>
      <ul>
        <li>إصدار التراخيص الزراعية للمزارعين والمزارع</li>
        <li>تصاريح استيراد وتصدير المنتجات النباتية والحيوانية</li>
        <li>دعم الأسمدة والبذور والمعدات الزراعية</li>
        <li>برامج الإرشاد الزراعي والتعليم الزراعي</li>
        <li>تنظيم المعارض والأسواق الزراعية المحلية</li>
      </ul>
    </div>

    <div class="section">
        <h2>التقديم على خدمة</h2>
      
        <label for="service">اختر الخدمة</label>
        <select id="service" onchange="showForm()" name="service">
          <option value="">-- اختر --</option>
          <option value="farm">ترخيص مزرعة جديدة</option>
          <option value="support">طلب دعم زراعي</option>
          <option value="import">تصريح استيراد</option>
          <option value="export">تصريح تصدير</option>
        </select>
      
        <!-- Farm License Form -->
        <form id="form-farm" class="service-form" style="display: none;" enctype="multipart/form-data">
          <label>الاسم الكامل</label>
          <input type="text" name="name" required>
      
          <label>موقع الأرض</label>
          <input type="text" name="location" required>
      
          <label>نوع المزرعة</label>
          <input type="text" name="farmType" required>
      
          <label>صورة مستند ملكية الأرض</label>
          <input type="file" name="ownershipDocument" accept="image/*,application/pdf" onchange="previewImage(this, 'ownershipPreview1')" required>
          <div id="ownershipPreview1" class="preview-box"></div>
      
          <label>صورة الوجه</label>
          <input type="file" name="facePhoto" accept="image/*" onchange="previewImage(this, 'facePreview1')" required>
          <div id="facePreview1" class="preview-box"></div>
      
          <label>صورة الهوية الشخصية</label>
          <input type="file" name="idPhoto" accept="image/*" onchange="previewImage(this, 'idPreview1')" required>
          <div id="idPreview1" class="preview-box"></div>
      
          <button type="submit">إرسال الطلب</button>
        </form>
      
        <!-- Agricultural Support Form -->
        <form id="form-support" class="service-form" style="display: none;" enctype="multipart/form-data">
          <label>الاسم الكامل</label>
          <input type="text" name="name" required>
      
          <label>نوع الدعم المطلوب</label>
          <input type="text" name="supportType" required>
      
          <label>تفاصيل المشروع الزراعي</label>
          <textarea name="details" rows="4"></textarea>
      
          <label>صورة الوجه</label>
          <input type="file" name="facePhoto" accept="image/*" onchange="previewImage(this, 'facePreview2')" required>
          <div id="facePreview2" class="preview-box"></div>
      
          <label>صورة الهوية الشخصية</label>
          <input type="file" name="idPhoto" accept="image/*" onchange="previewImage(this, 'idPreview2')" required>
          <div id="idPreview2" class="preview-box"></div>
      
          <button type="submit">إرسال الطلب</button>
        </form>
      
        <!-- Import Permit Form -->
        <form id="form-import" class="service-form" style="display: none;" enctype="multipart/form-data">
          <label>الاسم الكامل</label>
          <input type="text" name="name" required>
      
          <label>المنتج المستورد</label>
          <input type="text" name="product" required>
      
          <label>بلد المنشأ</label>
          <input type="text" name="country" required>
      
          <label>الكمية المطلوبة</label>
          <input type="text" name="quantity" required>
      
          <label>صورة الوجه</label>
          <input type="file" name="facePhoto" accept="image/*" onchange="previewImage(this, 'facePreview3')" required>
          <div id="facePreview3" class="preview-box"></div>
      
          <label>صورة الهوية الشخصية</label>
          <input type="file" name="idPhoto" accept="image/*" onchange="previewImage(this, 'idPreview3')" required>
          <div id="idPreview3" class="preview-box"></div>
      
          <button type="submit">إرسال الطلب</button>
        </form>
      
        <!-- Export Permit Form -->
        <form id="form-export" class="service-form" style="display: none;" enctype="multipart/form-data">
          <label>الاسم الكامل</label>
          <input type="text" name="name" required>
      
          <label>المنتج المراد تصديره</label>
          <input type="text" name="product" required>
      
          <label>البلد المستهدف</label>
          <input type="text" name="destination" required>
      
          <label>تفاصيل الشحنة</label>
          <textarea name="details" rows="4"></textarea>
      
          <label>صورة الوجه</label>
          <input type="file" name="facePhoto" accept="image/*" onchange="previewImage(this, 'facePreview4')" required>
          <div id="facePreview4" class="preview-box"></div>
      
          <label>صورة الهوية الشخصية</label>
          <input type="file" name="idPhoto" accept="image/*" onchange="previewImage(this, 'idPreview4')" required>
          <div id="idPreview4" class="preview-box"></div>
      
          <button type="submit">إرسال الطلب</button>
        </form>
      </div>
      

    <div class="section">
      <h2>تواصل معنا</h2>
      <p>
        العنوان: بيروت، العدلية - قرب قصر العدل<br>
        الهاتف: 01-123456<br>
        البريد الإلكتروني: info@agriculture.gov.lb<br>
        الموقع الرسمي: <a href="http://www.agriculture.gov.lb" target="_blank">agriculture.gov.lb</a>
      </p>
    </div>

    <a href="ministries.html" class="back-link">⬅️ العودة إلى صفحة الوزارات</a>

  </div>

  <script>
    function showForm() {
      const selected = document.getElementById("service").value;
      const forms = document.querySelectorAll(".service-form");
      forms.forEach(form => form.style.display = "none");
  
      if (selected) {
        const targetForm = document.getElementById("form-" + selected);
        if (targetForm) targetForm.style.display = "block";
      }
    }
  
    function previewImage(input, previewId) {
      const preview = document.getElementById(previewId);
      preview.innerHTML = '';
  
      const file = input.files[0];
      if (!file) return;
  
      if (file.type.startsWith("image/")) {
        const reader = new FileReader();
        reader.onload = function (e) {
          const img = document.createElement("img");
          img.src = e.target.result;
          preview.appendChild(img);
        };
        reader.readAsDataURL(file);
      } else {
        preview.innerHTML = '<p>📄 تم اختيار ملف غير صورة.</p>';
      }
    }
  
    // Popup function
    function showSuccessPopup() {
      const popup = document.getElementById("successPopup");
      popup.style.display = "flex";
  
      setTimeout(() => {
        popup.style.display = "none";
      }, 3000);
    }
  
    // Attach validation and popup to all forms
    document.querySelectorAll(".service-form").forEach(form => {
      form.addEventListener("submit", function (e) {
        e.preventDefault(); // Prevent actual submission for demo
  
        const requiredFiles = form.querySelectorAll('input[type="file"][required]');
        let allValid = true;
  
        requiredFiles.forEach(input => {
          if (!input.files.length) {
            allValid = false;
            input.style.border = "2px solid red";
          } else {
            input.style.border = "";
          }
        });
  
        if (!allValid) {
          alert("يرجى تحميل جميع الصور المطلوبة قبل الإرسال.");
          return;
        }
  
        // Simulate success
        showSuccessPopup();
        form.reset();
  
        // Clear previews
        form.querySelectorAll('.preview-box').forEach(p => p.innerHTML = '');
      });
    });
  </script>
  
  
  
  <!-- Success Popup Modal -->
<div id="successPopup" style="display: none;" class="popup-overlay">
    <div class="popup-content">
      <h3>✅ تم الإرسال بنجاح</h3>
      <p>شكراً لتقديم الطلب! سيتم مراجعته قريباً.</p>
    </div>
  </div>
  

</body>
</html>

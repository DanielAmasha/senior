<?php
session_start();
include 'db.php';

// Predefined emails and roles
$admin_emails = [
    'super1@example.com' => 'super_admin',
    'super2@example.com' => 'super_admin',
    'super3@example.com' => 'super_admin',
    'ministryadmin1@example.com' => 'ministry_admin',
    'adminofministries@example.com' => 'admin_of_ministries'
];

$error = '';

// Only process POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize form data
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Validate that fields are not empty
    if (!empty($username) && !empty($email) && !empty($password)) {
        // Check if email already exists in the database
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Email is already registered.";
        } else {
            // Assign role based on predefined emails
            $role = isset($admin_emails[$email]) ? $admin_emails[$email] : 'user'; // Default role is 'user'

            // Hash password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Insert user into the database
            $insert = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
            $insert->bind_param("ssss", $username, $email, $hashedPassword, $role);

            if ($insert->execute()) {
                header("Location: login.php");
                exit;
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
    } else {
        $error = "All fields are required.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register</title>
  <link rel="stylesheet" href="styles.css?v=1"> <!-- Cache buster to avoid cached CSS issues -->
</head>
<body>
  <div class="container">
    <h2>Register</h2>

    <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>

    <form action="register.php" method="POST">
      <input type="text" name="username" placeholder="Username" required> <!-- Username field -->
      <input type="email" name="email" placeholder="Email" required> <!-- Email field -->
      <input type="password" name="password" placeholder="Password" required> <!-- Password field -->
      <button type="submit">Register</button>
    </form>

    <div class="switch-link">Already have an account? <a href="login.php">Login</a></div>
  </div>
</body>
</html>

<?php
include 'db.php'; // Include the database connection

// Fetch ministries from the database for the dropdown
$ministries_query = "SELECT * FROM ministries";
$ministries_result = $conn->query($ministries_query);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ministry_id = $_POST['ministry_id'];
    $service_name = $_POST['name'];
    $service_description = $_POST['description'];

    // Insert data into the services table
    $query = "INSERT INTO services (ministry_id, name, description) VALUES ('$ministry_id', '$service_name', '$service_description')";
    if ($conn->query($query) === TRUE) {
        echo "Service added successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<form method="POST" action="add_service.php">
    <label>Ministry:</label>
    <select name="ministry_id">
        <?php while ($row = $ministries_result->fetch_assoc()) { ?>
            <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
        <?php } ?>
    </select>
    
    <label>Service Name:</label>
    <input type="text" name="name" required>
    
    <label>Description:</label>
    <textarea name="description"></textarea>
    
    <button type="submit">Add Service</button>
</form>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
    <!-- Link to external CSS -->
    <link rel="stylesheet" href="styles.css">


</head>
<body>
    <div class="container">
        <h2>Logging out...</h2>
        <?php
            session_start();
            session_unset();
            session_destroy();
            header("Location: home.php");
            exit();
        ?>
    </div>
</body>
</html>
C:\xampp\htdocs\senior_web\styles.css
C:\xampp\htdocs\senior_web\logout.php
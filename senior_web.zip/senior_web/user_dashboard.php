<?php
session_start();
if ($_SESSION['role'] != 'user') {
    header("Location: login.php");
    exit();
}
?>

<h1>مرحبًا، <?php echo $_SESSION['email']; ?></h1>
<p>أنت حالياً في لوحة المستخدم.</p>

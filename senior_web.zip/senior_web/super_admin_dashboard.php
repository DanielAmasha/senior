<?php
session_start();
if ($_SESSION['role'] != 'super_admin') {
    header("Location: login.php");
    exit();
}

include 'db.php';
?>

<h1>مرحبًا، <?php echo $_SESSION['email']; ?></h1>
<p>أنت حالياً في لوحة تحكم المدير العام.</p>
<p>إدارة جميع الوزارات والمستخدمين هنا.</p>
<a href="add_admin.php">إضافة مسؤول جديد</a>
<a href="manage_all_ministries.php">إدارة جميع الوزارات</a>

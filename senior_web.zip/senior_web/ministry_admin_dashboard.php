<?php
session_start();
if ($_SESSION['role'] != 'ministry_admin') {
    header("Location: login.php");
    exit();
}
?>

<h1>مرحبًا، <?php echo $_SESSION['email']; ?></h1>
<p>أنت حالياً في لوحة تحكم مدير الوزارة.</p>
<p>تستطيع إدارة خدمات الوزارة الخاصة بك هنا.</p>

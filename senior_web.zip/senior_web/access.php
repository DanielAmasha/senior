<?php
session_start();

// Check if the user came from the 'Ministries' link
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['from']) && $_POST['from'] === 'ministries') {
    $_SESSION['redirect_after_login'] = 'ministries.html';  // Save the redirect URL in session
}

// Show signup page if requested
$show_signup = isset($_GET['signup']);

// Generate CSRF token for form security
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Generate a token
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Access Portal</title>
    <link rel="stylesheet" href="styles.css?v=1"> <!-- Include CSS for consistency -->
</head>
<body>
    <h1><?= $show_signup ? 'Register' : 'Login' ?></h1>

    <form method="POST" action="<?= $show_signup ? 'register.php' : 'login.php' ?>">
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required><br>

        <!-- CSRF Token -->
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

        <?php if ($show_signup): ?>
            <input type="text" name="full_name" placeholder="Full Name" required><br>
            <select name="role" required>
                <option value="user">User</option>
                <option value="ministry_admin">Ministry Admin</option>
                <option value="admin_of_ministries">Admin of Ministries</option>
                <option value="super_admin">Super Admin</option>
            </select><br>
        <?php endif; ?>

        <button type="submit"><?= $show_signup ? 'Register' : 'Login' ?></button>
    </form>

    <p>
        <?= $show_signup ? 'Already have an account? <a href="access.php">Login here</a>' : 'Don\'t have an account? <a href="access.php?signup=1">Register here</a>' ?>
    </p>
</body>
</html>

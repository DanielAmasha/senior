<?php
header("Content-Type: application/json");

// ✅ Your API Key here
$apiKey = "431f645ecbde4b23be5d706b9dc78547";

// ✅ The NewsAP431f645ecbde4b23be5d706b9dc78547I URL
$url = "https://newsapi.org/v2/everything?q=lebanon&sortBy=publishedAt&pageSize=5&apiKey=$apiKey";

// ✅ Initialize cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// ✅ Add required User-Agent header
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  "User-Agent: MyGovProject/1.0"
]);

$response = curl_exec($ch);

// ✅ Error Handling
if(curl_errno($ch)) {
    echo json_encode([
        "status" => "error",
        "message" => "cURL error: " . curl_error($ch)
    ]);
    curl_close($ch);
    exit;
}

curl_close($ch);

// ✅ Output the response from NewsAPI
echo $response;
<?php
session_start();
if ($_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}
?>

<h1>مرحبًا، <?php echo $_SESSION['email']; ?></h1>
<p>أنت حالياً في لوحة تحكم المدير.</p>
<a href="add_ministry.php">إضافة وزارة جديدة</a>
<a href="manage_services.php">إدارة الخدمات</a>

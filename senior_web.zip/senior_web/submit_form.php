<?php
include 'db.php'; // Include the database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $service_id = $_POST['service_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // Insert submission into the submissions table
    $query = "INSERT INTO submissions (service_id, name, email, phone) VALUES ('$service_id', '$name', '$email', '$phone')";
    if ($conn->query($query) === TRUE) {
        $submission_id = $conn->insert_id; // Get the last inserted submission ID
        
        // Handle file uploads
        foreach ($_FILES['files']['tmp_name'] as $key => $tmp_name) {
            $file_name = $_FILES['files']['name'][$key];
            $file_tmp = $_FILES['files']['tmp_name'][$key];
            $file_type = $_FILES['files']['type'][$key];

            // Set file upload directory
            $file_path = 'uploads/' . $file_name;
            move_uploaded_file($file_tmp, $file_path);

            // Insert file data into the uploads table
            $upload_query = "INSERT INTO uploads (submission_id, file_name, file_path, file_type) VALUES ('$submission_id', '$file_name', '$file_path', '$file_type')";
            $conn->query($upload_query);
        }

        echo "Your submission was successful!";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<form method="POST" action="submit_form.php" enctype="multipart/form-data">
    <label>Service ID:</label>
    <input type="number" name="service_id" required>
    
    <label>Name:</label>
    <input type="text" name="name" required>
    
    <label>Email:</label>
    <input type="email" name="email">
    
    <label>Phone:</label>
    <input type="text" name="phone">
    
    <label>Upload Files:</label>
    <input type="file" name="files[]" multiple>
    
    <button type="submit">Submit</button>
</form>
